/**
 * Created by HAI on 5/28/2017.
 */
export * from './history.component';
