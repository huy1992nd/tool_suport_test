/**
 * Created by HAI on 5/24/2017.
 */
import {
  Component,
  OnInit,
  AfterViewInit 
} from '@angular/core';
import {NgbDateStruct, NgbCalendar} from '@ng-bootstrap/ng-bootstrap';
import  { LogService } from '../../service/log_server';
import  { TaskService } from '../../service/task_server';
import { Router } from '@angular/router';

@Component({
  selector: 'history',  // <home></home>
  
  providers: [

  ],
  templateUrl: './history.component.html',
  styleUrls: [
    'style.css'
  ]
    
})

export class HistoryComponent implements OnInit {
  // Set our default 
  
  errorMessage:string;
  public listTask: any;
  public listLog: any;
  public listLogAll: Array<any>;
  public task_select: any="";
  public search_content: any="";
  model: NgbDateStruct;
  date: {year: number, month: number};
  //datepicker
  public events: string[] = [];
  public date_start: Date = new Date(2010, 11, 0, 10);
  public date_end: Date = new Date(2050, 11, 0, 10);
  // TypeScript public modifiers
  constructor(public router: Router, calendar: NgbCalendar , private logService : LogService, private taskService : TaskService) {
  }
  public ngOnInit() {
    this.getListLog({'username':"demo"});
    this.getListTask();
  }
  selectTask(task){
    this.task_select = task;
    if(task.task_name != 'all'){
      this.listLog = this.listLogAll.filter(t=> t.task_name == task.task_name );
    }else{
      this.listLog = this.listLogAll;
    }
  }

  onChangeStart(e){
     console.log(e);
     var condition = {
       username:'root',
       time:{
        "start": e.toISOString(),
        "end": this.date_end.toISOString()
      }
     }
     this.getListLog(condition);
  }

  onChangeEnd(e){
     console.log(e);
     var condition = {
      username:'root',
      time:{
       "start": this.date_start.toISOString(),
       "end": e.toISOString()
     }
    }
    this.getListLog(condition);
  }

  async getListLog(condition) {
    var logObject = await this.logService.ListLog(condition);
    if(logObject.resultCode == 55){
      this.router.navigate(['login']);
    }
    this.listLogAll = logObject.list_log;
    this.listLog =this.listLogAll;
  }

  async getListTask(){
    var taskObject = await this.taskService.listTask({});
    this.listTask = taskObject.list_task;
    this.listTask.unshift({
      task_name:'all',
      task_name_detail:'Select All'
    });
  }

  l


}
